<?php
$catalog=[];
//$container=[];

/*$container[0]=["id"=>0];
$container[1]=["id"=>1];
$container[2]=["id"=>2];
$container[3]=["id"=>3];*/

$catalog[0] = [
    "id"=>0,
    "title"=>"Design Patterns: Elements of Reusable Object-Oriented Software",
    "img"=>"images/design_patterns.jpg",
    "year"=>1994,
    "authors" => [
        "Erich Gamma",
        "Rickarn Helm",
        "Ralph Johnson",
        "John Vlissides"
    ],
    "publisher"=>"Prentice Hall",
    "isbn"=>"978-0201633510"
];
$catalog[1] = [
    "id"=>1,
    "title"=>"Clean Code: A Handbook of Alige Software Craftsmanship",
    "img"=>"images/clean_code.jpg",
    "year"=>2008,
    "authors" => [
        "Robert C. Martin"
    ],
    "publisher"=>"Prentice Hall",
    "isbn"=>"978-0132350884"
];
$catalog[2] = [
    "id"=>2,
    "title"=>"Refactoring: Improving the Design of Existing Code",
    "img"=>"images/refactoring.jpg",
    "year"=>1999,
    "authors" => [
        "Martin Fowler",
        "Kent Beck",
        "John Brant"
    ],
    "publisher"=>"Addison-Wesley Professional",
    "isbn"=>"978-0201485677"
];
$catalog[3] = [
    "id"=>3,
    "title"=>"Machine Learning in Action",
    "img"=>"images/MachineLearning.PNG",
    "year"=>2012,
    "authors" => [
        "Peter Harrington"
    ],
    "publisher"=>"Manning Publications Co.",
    "isbn"=>"978-1617290183"
];

?>