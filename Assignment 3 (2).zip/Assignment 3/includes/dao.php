<?php

function getCountByGender($var){
    $database = EmployeeDatabase::getInstance();
    $db=$database->connect();

    $query = 'SELECT COUNT(*) as count FROM employees WHERE gender=:gender;';
    $statement=$db->prepare($query);
    $statement->bindValue(":gender", $var);
    $statement->execute();

    $row=$statement->fetch();
    $statement->closeCursor();

    return $row['count'];
}


function getTableData(){
    $database = EmployeeDatabase::getInstance();
    $db=$database->connect();

    $query = 'SELECT * FROM employees LIMIT 200;';
    $statement=$db->prepare($query);
    $statement->execute();

    $employees = $statement->fetchAll();
    $statement->closeCursor();

    return $employees;
}

function getDept($item){

    $database = EmployeeDatabase::getInstance();
    $db=$database->connect();
    ?>
    <console class="log"><?php $item ?></console>
    <?php

    /*?><h1><?php echo array_search($item,$depts);?></h1><?php*/

    $query = "SELECT employees.emp_no, employees.first_name, employees.last_name, employees.gender, employees.hire_date
    FROM employees,dept_emp
    WHERE dept_no = :item and employees.emp_no=dept_emp.emp_no LIMIT 100;";
    $statement=$db->prepare($query);/*?><script>alert(<?php $query ?>)</script><?php*/
    $statement->bindValue(":item",$item);
    $statement->execute();

    $employees = $statement->fetchAll();
    $statement->closeCursor();

    /*?>
    <console class="log">$query</console>
    <?php*/
    return $employees;
    /*
    mysql> SELECT emp.emp_no, emp.first_name, emp.last_name, emp.gender, emp.hire date
    FROM employees AS emp, dept_emp AS dept
    WHERE dept_no="d008" and emp.emp_no=dept.emp_no
    LIMIT 100
    */
}

?>