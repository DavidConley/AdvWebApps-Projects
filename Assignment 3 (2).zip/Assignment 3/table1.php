<div class="container">
    <div class="card" style="width:100%; border:blue">
    <div class="card body" style="width:100%; border:blue">
        <div class="row">
            <table id="data_table" class="table table-striped table-bordered" style="width:90%">
                <thead>
                    <tr>
                        <th>Employee Number</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Hire Date</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
        
                <?php
                    $employees=getTableData();
                    foreach($employees as $employee):
                ?>

                <tr>
                    <td><?php echo $employee['emp_no']; ?></td>
                    <td><?php echo $employee['first_name']; ?></td>
                    <td><?php echo $employee['last_name']; ?></td>
                    <td><?php echo $employee['gender']; ?></td>
                    <td><?php echo $employee['hire_date']; ?></td>
                    <td class="text-center">
                        <i class="text-info bi bi-pencil-fill" style="cursor:pointer"></i>
                    </td>
                    <td class="text-center">
                        <i class="text-info bi bi-trash" style="cursor:pointer"></i>
                    </td>
                </tr>

                <?php endforeach ?>
            </table>
        </div>
    </div>
    </div>
</div>

<?php

?>