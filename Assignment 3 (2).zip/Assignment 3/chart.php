<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.js"></script>

<?php
    $female_count=getCountByGender('F');
    $male_count=getCountByGender('M');
?>

<div class="container">
    <div class="card">
        <div class="card-body">
            <canvas id="PieChart" width="120%" height="50%"></canvas>
        </div>
    </div>
</div>

<script>
    var ctx = document.getElementById("PieChart");

    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Female','Male'],
            datasets: [{
                //data: [100, 50],
                data: [<?php echo $female_count;?>, <?php echo $male_count;?>],
                backgroundColor:['red','green']
            }]
        }
    });
</script>