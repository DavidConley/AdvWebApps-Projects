"use strict"

$(document).ready(function(){
    tabling();
    charting();

    $('#fractTop').on('click', function(){
        if(!hasClass(document.getElementById('fractTop'),'topperPress')){
            $(this).removeClass('topper').addClass('topperPress');
            $('#percTop').removeClass('topperPress').addClass('topper');
            tabling();
        }
    })
    $('#percTop').on('click', function(){
        if(!hasClass(document.getElementById('percTop'),'topperPress')){
            $(this).removeClass('topper').addClass('topperPress');
            $('#fractTop').removeClass('topperPress').addClass('topper');
            tabling();
        }
    })

    $('#left').on('click', function(){
        if(everything == 0){
            whichChart=whichChart-1;
            newChart.destroy();
            charting();
        }
    })

    $('#right').on('click', function(){
        if(everything == 0){
            whichChart=whichChart+1;
            newChart.destroy();
            charting();
        }
    })

    $('#slide').on('click', function(){
        if(everything == 0 && slider == 0){
            slider=1;
            sliding();
        }
        else if(everything == 0 && slider == 1){
            slider=0;
        }
    })

    $('#all').on('click', function(){
        if(everything == 0){
            document.getElementById('all').textContent='Totals';
            everything = 1;
            slider=0;
            $('#slide').removeClass('bottomer').addClass('bottomer3');
            $('#left').removeClass('bottomer').addClass('bottomer3');
            $('#right').removeClass('bottomer').addClass('bottomer3');
            newChart.destroy();
            charting();
        }
        else if(everything == 1){
            document.getElementById('all').textContent='All';
            everything = 0;
            $('#slide').removeClass('bottomer3').addClass('bottomer');
            $('#left').removeClass('bottomer3').addClass('bottomer');
            $('#right').removeClass('bottomer3').addClass('bottomer');
            newChart.destroy();
            charting();
        }
    })

    

    $("#upload").on('change', function () {
        $("#FileUpload").submit();
    });

    $("#saver").on('click', function () {
        capture();
    });

    /**$('#upload').on('change', function(){
        test=[[]];
        console.log(document.getElementById("upload").files); // list of File objects

        var file = document.getElementById("upload").files[0];
        var reader = new FileReader();
        var filer = reader.readAsText(file);
        console.log(filer);
        test=Papa.parse(filer);
        tabling();
        charting();
    })**/
    

    /**var filer = [],
    upload = document.getElementById("upload");

    upload.onchange = function() {
        for (var i=0;i<upload.filer.length;i++) {
            filer.push(upload.filer[i].fileName);
        }
        //test=Papa.parse(filer);
        tabling();
        charting();
    }**/


})

function sliding(){
    if(slider==1 && everything == 0){
        whichChart=whichChart+1;
        newChart.destroy();
        charting();
        setTimeout(sliding, 4000);
    }
}

function hasClass(element, clsName) {
    return(' ' + element.className + ' ').indexOf(' ' + clsName + ' ') > -1;
}


/**function tableMaker(tableData){
    var table = $('<table></table>');
    $(tableData).each(function (i, rowData) {
        var row = $('<tr></tr>');
        $(rowData).each(function (j, cellData) {
            row.append($('<td>'+cellData+'</td>'));
        });
        table.append(row);
    });
    return table;
}

$.ajax({
    type:"GET", url:"Example sheet.csv", success:function(data){
        $('tablespace').append(tableMaker(Papa.parse(data).data));
    }
})

$("upload").on("change", function(evt) {
    alert("Clicked");
    var f = evt.target.files[0];
    if (f) {
        var r = new FileReader();
        r.onload = function(e) {
            var CSVARRAY = parseResult(e.target.result);
        }
        alert("File loaded");
        r.readAsText(f);
    } else {
        alert("Failed to load file");
    }
});
function parseResult(result) {
    var resultArray = [];
    result.split("\n").forEach(function(row) {
        var rowArray = [];
        alert("Row");
        row.split(",").forEach(function(cell) {
            rowArray.push(cell);
            alert("Cell");
        });
        resultArray.push(rowArray);
    });
    return resultArray;
}**/

/**function Upload(e) {
    var data = null;
    var file = e.target.files[0];

    var reader = new FileReader();
    reader.readAsText(file.asInstanceOf[Blob]);
    reader.onload = function (event) {
        var csvData = event.target.result;

        var parsedCSV = d3.csv.parseRows(csvData);

        parsedCSV.forEach(function (d, i) {
            if (i == 0) return true; // skip the header
            document.getElementById(d[0]).value = d[1];
        });
    }
}**/

/**function Upload() {
    alert("Clicked");
    var reader = new FileReader();
    reader.onload = function (e) {
        alert("Start");
        var table = document.createElement("table");
        var rows = e.target.result.split("\n");
        for (var i = 0; i < rows.length; i++) {
            var cells = rows[i].split(",");
            if (cells.length > 1) {
                var row = table.insertRow(-1);
                for (var j = 0; j < cells.length; j++) {
                    var cell = row.insertCell(-1);
                    cell.innerHTML = cells[j];
                    alert("Cell");
                }
            }
        }
        var gridspace = document.getElementbyId("gridspace");
        gridspace.innerHTML = "";
        gridspace.appendChild(table);
    }
}**/

/**function Upload() {
    alert("Clicked");
    var filer = (function() { return document.getElementById("upload").files; })();
    test=Papa.parse(filer);
    tabling();
    charting();
}**/

/**function Upload(){
    var test = [];
    var csv = (function() { return document.getElementById("upload").files; })();

    var rows = csv.split("\n");

    for (var i = 0; i < rows.length; i++) {
    var cells = rows[i].split(",");
    test.push( cells );
    }

    console.dir(data);
}**/

/**var Upload = function(event) {
    var reader = new FileReader();
    reader.onload = (event) => {
      this.processData(event.target.result)
    }
      //reader.onerror = this.errorHandler;
      // Read file into memory as UTF-8
      // console.log(reader.onload)
      reader.readAsText(event.asInstanceOf[Blob]);
};

var processData = function(csv) {
    var allTextLines = csv.split(/\r\n|\n/);
    var lines = [];
    while (allTextLines.length) {
        lines.push(allTextLines.shift().split(','));
    }
    console.log(lines);
    this.arraysToObjects(lines);
  }

  var arraysToObjects = function(lines) {
    var i
    var j
    test = []
    for (j=0; j < lines.length; j ++) {
      test[j]=[];
      for (i = 0; i < lines[0].length; i++) {
        test[j][i] = lines[j][i];
        alert(test[j][i]);
      }
    }
  console.log(outputArray)
  tabling();
  charting();
};**/



/**function Upload(){
    var reader = new FileReader();

reader.onload = function (e) {
    var arr = e.target.result.split("\n");
    // Continue processing...
};

reader.readAsText(document.getElementById("FileUpload").files[0]);
}**/

/**function Upload() {
    var file = upload.files[0];
    var textType = /text./;
    var csvType = 'text/csv';
    if (file.type.match(csvType)) {
      var reader = new FileReader();
      reader.onload = function(e) {
        document.getElementById("csvData").innerHTML = process(reader.result);
      }
  
      reader.readAsText(file);
    } else {
      fileDisplayArea.innerText = "File not supported!";
    }
  }

  function process(dataString) {
    var lines = dataString
      .split(/\n/)                     // Convert to one string per line
      .map(function(lineStr) {
          return lineStr.split(",");   // Convert each line to array (,)
      })
      .slice(1);                       // Discard header line
    
    return JSON.stringify(lines, null, 2);
  }**/

/**document.getElementById("upload").addEventListener("change", upload, false);

function upload(e) {

    var data = null;
    var file = e.target.files[0];

    var reader = new FileReader();
    reader.readAsText(file);
    reader.onload = function (event) {
        var csvData = event.target.result;

        var test = d3.csv.parseRows(csvData);

        test.forEach(function (d, i) {
            if (i == 0) return true; // skip the header
            document.getElementById(d[0]).value = d[1];
        });

    }
}**/

function readCSVFile(){
    var files = document.querySelector('#upload').files;

    if(files.length > 0 ){

        // Selected file
        var file = files[0];

        // FileReader Object
        var reader = new FileReader();

        // Read file as string 
        reader.readAsText(file);

        // Load event
        reader.onload = function(event) {

            // Read file data
            var csvdata = event.target.result;

            // Split by line break to gets rows Array
            var rowData = csvdata.split('\n');

            // <table > <tbody>
            //var tbodyEl = document.getElementById('tblcsvdata').getElementsByTagName('tbody')[0];
            //tbodyEl.innerHTML = "";
            test=[[]];
            test2=[[""]];
            test3=[[""]];

            // Loop on the row Array (change row=0 if you also want to read 1st row)
            for (var row = 0; row < rowData.length-1; row++) {

                // Insert a row at the end of table
                //var newRow = tbodyEl.insertRow();
                test[row]=[""];

                // Split by comma (,) to get column Array
                var rowColData = rowData[row].split(',');

                // Loop on the row column Array
                for (var col = 0; col < rowColData.length; col++) {

                    // Insert a cell at the end of the row
                    //var newCell = newRow.insertCell();
                    //newCell.innerHTML = rowColData[col];
                    if(col!=0 && row!=0){
                        test[row][col]=eval(rowColData[col].split('\r').join(""));
                    }
                    else{
                        test[row][col]=rowColData[col].split('\r').join("");
                    }
                }
            }
            newChart.destroy();
            tabling();
            charting();
        };
    }
    else{
         alert("Please select a file.");
    }
}

function capture() {
    const captureElement = document.querySelector('#capture') // Select the element you want to capture. Select the <body> element to capture full page.
    html2canvas(captureElement)
        .then(canvas => {
            //canvas.style.display = 'none'
            document.body.appendChild(canvas)
            return canvas
        })
        .then(canvas => {
            const image = canvas.toDataURL('image/png')
            const a = document.createElement('a')
            a.setAttribute('download', 'grade-calculator.png')
            a.setAttribute('href', image)
            a.click()
            canvas.remove()
        })
}

//const saver = document.querySelector('#saver')
//saver.addEventListener('click', capture)