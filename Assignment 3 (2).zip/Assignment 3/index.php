<?php
    require 'includes/database.php';
    require 'includes/data.php';
    require 'includes/dao.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"></link>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"></link>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css"></link>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css"></link>
</head>
<body>

    <nav class="navbar bg-dark navbar-dark">
        <div class="container">
            <h1 class="navbar-brand">Employee Dashboard
                &nbsp;&nbsp;&nbsp;&nbsp;
                <i class="bi-speedometer2 fs-1"></i>
            </h1>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row min-vh-100">
            <div class="col-auto bg-light">

                <div class="nav p-3">
                    <ul class="nav flex-column">

                        <li class="nav-item"><a href="#home">
                            <i class="bi-house fs-1"></i>
                        </a></li>

                        <li class="nav-item"><a href="#chart">
                            <i class="bi bi-pie-chart-fill fs-1"></i>
                        </a></li>

                        <li class="nav-item"><a href="#table">
                            <i class="bi-table fs-1"></i>
                        </a></li>

                    </ul>
                </div>
            </div>

            <div class="col">
                <div id="home" class="tab-content">
                    <nav class="navbar bg-primary navbar-dark">
                        <h1 class="navbar-brand font-italic">&nbsp;&nbsp;<i class="bi-people-fill fs-1"></i>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        Departments</h1>
                    </nav>
                    <!--<form action="" method="get">-->
                    <div class="row justify-content-center pt-5">
                        <div class="table w-50" method="get">
                        <?php
                        global $clickedId;
                        global $gotVal;
                        //$clickedId = '0';
                        //$gotVal=$_GET['gotVal'] ?? '';
                        require 'includes/data.php';
                        foreach($depts as $item){
                        //echo $item . "\n";
                        //echo "<button onsubmit=".getDept($item, $depts).">" . array_search($item,$depts) . "</button><br>";}
                        ?><button class='tableBringer' id='<?php echo array_search($item,$depts) ?>' name='<?php echo $item ?>'><?php echo array_search($item,$depts) ?></button><br><?php ;}
                        /*?><button class='tableBringer' name='<?php echo array_search($item,$depts) ?>' onclick="<?php getDept($item, $depts) ?>"><?php echo array_search($item,$depts) ?></button><br><?php ;}*/
                        //echo "<a href='$_GET[$item]'>" . array_search($item,$depts) . "</a><br>";
                        
                        ?>

                        </div>
                        <img class="w-50" src="images/heart.png" alt="image">
                    </div>
                    <!--Make this only appear when a button is clicked. Event listeners?-->
                    <div class="tableShown row justify-content-center pt-5">
                        <h1 class="deptHead"></h1>
                        <?php require 'table2.php'; ?>
                        <!--<card class="card deptCard">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Employee Number</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Gender</th>
                                        <th>Hire Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $employees=getDept($clickedId);
                                        foreach($employees as $employee):
                                    ?>
                                    <tr>
                                        <td><?php echo $employee['emp_no']; ?></td>
                                        <td><?php echo $employee['first_name']; ?></td>
                                        <td><?php echo $employee['last_name']; ?></td>
                                        <td><?php echo $employee['gender']; ?></td>
                                        <td><?php echo $employee['hire_date']; ?></td>
                                    </tr>
                                    <?php endforeach ?>
                                
                                </tbody>
                            </table>
                        </card>-->
                    </div>
                    <!--</form>-->
                </div>

                <div id="chart" class="tab-content">
                    <!--<nav class="navbar bg-primary navbar-dark">
                        <h1 class="navbar-brand">&nbsp;&nbsp;<i class="bi bi-pie-chart-fill fs-1"></i>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        Chart</h1>
                    </nav>-->
                    <?php require 'chart.php'; ?>
                </div>

                <div id="table" class="tab-content">
                    <!--<nav class="navbar bg-primary navbar-dark">
                        <h1 class="navbar-brand">&nbsp;&nbsp;<i class="bi-table fs-1"></i>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        Table</h1>
                    </nav>-->
                    <?php require 'table1.php'; ?>
                </div>
            </div>

        </div>
    </div>
    
<script
  src="https://code.jquery.com/jquery-3.6.4.js"
  integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
  crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>

<script src="app.js"></script>
</body>
</html>