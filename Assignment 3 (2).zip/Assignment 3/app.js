"use strict";

$(document).ready(()=>{

    const table = $("data_table").DataTable({
        dom: 'Bfrtip',
        buttons: [

        ],
    });

    $("data_table tbody").on('click','td',function() {
        var data = table.row($(this).parents('tr')).data();
        if(table.cell(this).index().column==5){
            alert("Action Edit");
        }
        if(table.cell(this).index().column==6){
            alert("Action Delete");
        }

        console.log(data);
    })

    $('.nav ul li:first').addClass('active');
    $('.tab-content:not(:first)').hide();
    $('.nav ul li a').click(function(e) {
        e.preventDefault();
        var content=$(this).attr('href');
        $(this).parent().addClass('active');
        $(this).parent().siblings().removeClass('active');
        $(content).show();
        $(content).siblings('.tab-content').hide();
        
    })

    /*if(!$('.tableShown').hasClass('.active')){
        $('.tableShown').hide();
    }*/
    $('.tableBringer').click(function(){
        //$('.tableShown').addClass('active');
        //$('.tableShown').show();
        var clickVal = $(this).attr('name');

        
        //return clickedId;

        location.href = 'index.php?id='+clickVal;
        $('.deptHead').html($(this).attr('id'));
        $.ajax({url:'table2.php', type:'get', data:clickVal, success:function(data){$('.deptHead').innerText=($(this).attr('id')); return $('clickVal').html(data);}});
        //$.get("index.php", {gotVal:clickVal},function(data){alert("Success")}, "json");
        //document.cookie="gotVal=clickVal";

        //var employees=$.ajax({url: 'includes/dao.php', type: 'get', data: {"getDept": clickedId}, success:alert(clickedId)});
        //var count = 10;

        //$(employees).each(function(index=$(this)){ alert(index);})
        //for(var index = 0; index < count; index++ ){ alert(index);};

        //alert($(employees).text());

        //var emps = $(employees).each(function(value){"<tr><td>"+toString(value['emp_no']);+"</td><td>"+toString(value['first_name']);+"</td><td>"+toString(value['last_name']);+"</td><td>"+toString(value['gender']);+"</td><td>"+ toString(value['hire_date']);+"</td></tr>"});
        //alert(emps);
        //$('.deptCard').html($(emps));

        //var newTable = "<table class='table table-striped table-bordered'><thead><tr><th>Employee Number</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>Hire Date</th></tr></thead><tbody><?php $employees=getDept('"+$(this).attr("id")+"'); foreach($employees as $employee): ?><tr><td><?php echo $employee['emp_no']; ?></td><td><?php echo $employee['first_name']; ?></td><td><?php echo $employee['last_name']; ?></td><td><?php echo $employee['gender']; ?></td><td><?php echo $employee['hire_date']; ?></td></tr><?php endforeach ?></tbody></table>"
        //var newTable = "<table class='table table-striped table-bordered'><thead><tr><th>Employee Number</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>Hire Date</th></tr></thead><tbody>"+$(employees).each(function(index=$(this)){+"<tr><td>"+index.emp_no;+"</td><td>"+index.first_name;+"</td><td>"+index.last_name;+"</td><td>"+index.gender;+"</td><td>"+ index.hire_date;+"</td></tr>"})+"</tbody></table>"
        //var newTable = "<table class='table table-striped table-bordered'><thead><tr><th>Employee Number</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>Hire Date</th></tr></thead><tbody>"+function(){for(var index=0;index<count;index++){+"<tr><td>"+index.emp_no;+"</td><td>"+index.first_name;+"</td><td>"+index.last_name;+"</td><td>"+index.gender;+"</td><td>"+ index.hire_date;+"</td></tr>"}}+"</tbody></table>"
        //alert(newTable);
       // var newTable = "<table class='table table-striped table-bordered'><thead><tr><th>Employee Number</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>Hire Date</th></tr></thead></table>";
        //for(var index = 0; index < count; index++ ){
        /**$(employees).each(function(){
            $(employees.emp_no).append(newTable);
            alert(employees.emp_no);
            $(employees.first_name).append(newTable);
            $(employees.last_name).append(newTable);
            $(employees.gender).append(newTable);
            $(employees.hire_date).append(newTable);
        });

        $('.deptCard').html($(newTable));**/

        
        /*<table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Employee Number</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Gender</th>
                                        <th>Hire Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                        var employees=$.ajax({url: 'includes/dao.php', type: 'get', data: {"getDept": $(this).attr("id")} });
                                        $.each($employees as $employee):
                                    <tr>
                                        <td>"+$employee['emp_no'].toString;+"</td>
                                        <td>"+$employee['first_name'].toString;+"</td>
                                        <td>"+$employee['last_name'].toString;+"</td>
                                        <td>"+$employee['gender'].toString;+"</td>
                                        <td>"+ $employee['hire_date'].toString;+"</td>
                                    </tr>
                                </tbody>
                            </table>*/
    })
})
