<?php
function get_item_html($id, $item){
    $output="<li><a href='details.php?id="
    . $id 
    . "'><img src="
    . $item["img"] 
    . " alt='"
    . $item["title"]
    . "'/>"
    ."</a></li>";

    return $output;
}

function sorter($key){
    //$sort=$_POST["order"];
    //echo $output = "ORDER BY '.mysql_real_escape_string($sort).' ASC";
    //return $output;
    return function ($a, $b) use ($key) {
        //echo $key;
        //global $id;
        //echo '<br>',$a["id"],': ',$a["title"],'; ',$b["id"],': ',$b["title"];
        if($key=='year'){
            //return [$b[$key],$b["id"]]<=>[$a[$key],$a["id"]];
            /*strnatcmp($b[$key], $a[$key]);
            if($b["id"] > $a["id"]){
                $temp = $b["id"];
                $b["id"] = $a["id"];
                $a["id"] = $temp;
            }*/
            return strnatcmp($b[$key], $a[$key]);
        }
        else{
            //return [$a[$key],$a["id"]]<=>[$b[$key],$b["id"]];
            /*strnatcmp($a[$key], $b[$key]);
            if($a["id"] > $b["id"]){
                $temp = $b["id"];
                $b["id"] = $a["id"];
                $a["id"] = $temp;
            }*/
            return strnatcmp($a[$key], $b[$key]);
        }
    /**return [
        $a["id"],
        $a["title"],
        $a["img"],
        $a["year"],
        $a["authors"],
        $a["publisher"],
        $a["isbn"]]
        <=>
        [$b["id"],
        $a["title"],
        $b["img"],
        $b["year"],
        $b["authors"],
        $b["publisher"],
        $b["isbn"]
    ];**/
    };
}
?>