"use strict";

//setup
//flipping the cards, but not back
$(document).ready(()=>{
    $(".cardflip").flip({
        trigger: 'manual'
    });
    $("#cardflip3").click(()=>{
        $("#cardflip3").flip(true);
        document.getElementById("cardflip3").classList.add("flipped");
        disabler();
        checker();
    });
    $("#cardflip4").click(()=>{
        $("#cardflip4").flip(true);
        document.getElementById("cardflip4").classList.add("flipped");
        disabler();
        checker();
    });
    $("#cardflip5").click(()=>{
        $("#cardflip5").flip(true);
        document.getElementById("cardflip5").classList.add("flipped");
        disabler();
        checker();
    });
})

//no typing in bet blank
$("[type='number']").keydown(function (evt) {
    evt.preventDefault();
});

//no changing bet blank once all are flipped
function disabler(){
    if(document.getElementById("cardflip3").classList.contains("flipped")||document.getElementById("cardflip4").classList.contains("flipped")||document.getElementById("cardflip5").classList.contains("flipped")){
        document.getElementById("better").classList.add("no-spinner");
    }
}

//card movement
function cutTheCards(){
    $("#cardflip1").animate({left:"1500px"}, 0);
    $("#cardflip2").animate({left:"1500px"}, 0);
    $("#cardflip3").animate({left:"1500px"}, 0);
    $("#cardflip4").animate({left:"1500px"}, 0);
    $("#cardflip5").animate({left:"1500px"}, 0);
    $("#cardflip1").animate({left:"0px"}, 200);
    setTimeout(()=>{
        $("#cardflip2").animate({left:"0px"}, 200);},300);
    setTimeout(()=>{
        $("#cardflip3").animate({left:"0px"}, 200);},600);
    setTimeout(()=>{
        $("#cardflip4").animate({left:"0px"}, 200);},900);
    setTimeout(()=>{
        $("#cardflip5").animate({left:"0px"}, 200);},1200);
    setTimeout(()=>{
        $("#cardflip1").flip("hover");document.getElementById("cardflip1").classList.add("flipped");},1500);
    setTimeout(()=>{
        $("#cardflip2").flip("hover");document.getElementById("cardflip2").classList.add("flipped");},1800);
    setTimeout(()=>{
        checker();},2100);
}

//assigning cards and images to array
function imgItem(src) {
    this.src = src;
}

const cards = [];
const cardpics = [];
var mycard1;
var mycard2;
var mycard3;
var mycard4;
var mycard5;
function deck(){
    const numbers = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
    const suits = ["club","diamond","heart","spade"];

    //const cards = [];
    var imgNum=0;
    for (let vSuit=0; vSuit<suits.length; vSuit++) {
        for (let vNumber=0; vNumber<numbers.length; vNumber++) {
            const cNumber=numbers[vNumber];
            const cSuit = suits[vSuit];
            cards.push({cNumber,cSuit});
            //console.log(cards[imgNum]);
            cardpics[imgNum]=new imgItem("img/"+cSuit+cNumber+".png");
            imgNum++;
        }
    }
    return cards;
}

//randomizing cards without overlap
function shuffle(){
    const cardshuf = deck();

    var rand1=Math.floor(Math.random()*51)
    var rand2=Math.floor(Math.random()*51)
    while(rand2==rand1){
        rand2=Math.floor(Math.random()*51)
    }
    var rand3=Math.floor(Math.random()*51)
    while(rand3==rand1||rand3==rand2){
        rand3=Math.floor(Math.random()*51)
    }
    var rand4=Math.floor(Math.random()*51)
    while(rand4==rand1||rand4==rand2||rand4==rand3){
        rand4=Math.floor(Math.random()*51)
    }
    var rand5=Math.floor(Math.random()*51)
    while(rand5==rand1||rand5==rand2||rand5==rand3||rand5==rand4){
        rand5=Math.floor(Math.random()*51)
    }
    document.getElementById("back1").src = cardpics[rand1].src;
    mycard1=cards[rand1];
    document.getElementById("back2").src = cardpics[rand2].src;
    mycard2=cards[rand2];
    document.getElementById("back3").src = cardpics[rand3].src;
    mycard3=cards[rand3];
    document.getElementById("back4").src = cardpics[rand4].src;
    mycard4=cards[rand4];
    document.getElementById("back5").src = cardpics[rand5].src;
    mycard5=cards[rand5];

    debugging();

}


//start game
var score=100;
var multiplier=0;
document.getElementById("scoreNum").innerHTML=score;
//document.getElementById("better").max=score //extreme mode
document.getElementById("better").value=10;
cutTheCards();
shuffle();

//reset button
var resetting = function(){
    score=100;
    multiplier=0;
    document.getElementById("scoreNum").innerHTML=score;
    //document.getElementById("better").max=score //extreme mode
    document.getElementById("better").min=1;
    document.getElementById("better").max=10;
    document.getElementById("better").value=10;
    document.getElementById("better").classList.remove("no-spinner");
    $(".cardflip").flip(false);
    document.getElementById("cardflip1").classList.remove("flipped");
    document.getElementById("cardflip2").classList.remove("flipped");
    document.getElementById("cardflip3").classList.remove("flipped");
    document.getElementById("cardflip4").classList.remove("flipped");
    document.getElementById("cardflip5").classList.remove("flipped");
    setTimeout(()=>{$(".cardflip").animate({left:"5000px"}, 300);},700);
    setTimeout(()=>{removal();cutTheCards();shuffle();},1200);
}
document.getElementById("reset").onclick = resetting;

//next button
var nextting = function(){
    document.getElementById("better").classList.remove("no-spinner");
    $("#cardflip3").flip(true);
    $("#cardflip4").flip(true);
    $("#cardflip5").flip(true);
    document.getElementById("cardflip3").classList.add("flipped");
    document.getElementById("cardflip4").classList.add("flipped");
    document.getElementById("cardflip5").classList.add("flipped");
    checker();
    score = score - document.getElementById("better").value + (document.getElementById("better").value * (multiplier));
    multiplier=0;
    document.getElementById("scoreNum").innerHTML=score;
    //document.getElementById("better").max=score; //extreme mode
    if(document.getElementById("better").min > score){
        document.getElementById("better").min=score;
    }
    else{
        document.getElementById("better").min=1;
    }
    if(document.getElementById("better").value > score){
        document.getElementById("better").value=score;
    }
    if(document.getElementById("better").max > score){
        document.getElementById("better").max=score;
        document.getElementById("better").value=score;
    }
    else{
        document.getElementById("better").max=10;
    }
    setTimeout(()=>{
    $(".cardflip").flip(false);
    document.getElementById("cardflip1").classList.remove("flipped");
    document.getElementById("cardflip2").classList.remove("flipped");
    document.getElementById("cardflip3").classList.remove("flipped");
    document.getElementById("cardflip4").classList.remove("flipped");
    document.getElementById("cardflip5").classList.remove("flipped");
    },1000);
    setTimeout(()=>{$(".cardflip").animate({left:"5000px"}, 300);},1600);
    setTimeout(()=>{removal();},2000);
    if(score > 0){
        setTimeout(()=>{cutTheCards();shuffle();},2000);
    }
    else{
        setTimeout(()=>{alert("Game Over, reset to try again.");},2000);
    }
}
document.getElementById("next").onclick = nextting;

//checking cards
function checker(){
    var check1=[];
    var check2=[];
    var check3=[];
    var check4=[];
    var check5=[];
    if(document.getElementById("cardflip1").classList.contains("flipped")){
        check1=mycard1;
    }
    else{
        check1.cSuit="ge";
        check1.cNumber="geg";
    }
    if(document.getElementById("cardflip2").classList.contains("flipped")){
        check2=mycard2;
    }
    else{
        check2.cSuit="gege";
        check2.cNumber="gegeg";
    }
    if(document.getElementById("cardflip3").classList.contains("flipped")){
        check3=mycard3;
    }
    else{
        check3.cSuit="fe";
        check3.cNumber="fef";
    }
    if(document.getElementById("cardflip4").classList.contains("flipped")){
        check4=mycard4;
    }
    else{
        check4.cSuit="fefe";
        check4.cNumber="fefef";
    }
    if(document.getElementById("cardflip5").classList.contains("flipped")){
        check5=mycard5;
    }
    else{
        check5.cSuit="fefefe";
        check5.cNumber="fefefef";
    }
    debugging();
    removal();

    //royal flush (AKQJ10 straight flush)
    if((check1.cNumber=="A"&&check2.cNumber=="K"&&check3.cNumber=="Q"&&check4.cNumber=="J"&&check5.cNumber=="10")
    &&(check1.cSuit==check2.cSuit&&check1.cSuit==check3.cSuit&&check1.cSuit==check4.cSuit&&check1.cSuit==check5.cSuit)){
        console.log("Royal Flush")
        document.getElementById("RoyalFlush").classList.add("highlight");
        multiplier=10;
    }

    //four of a kind
    else if((check1.cNumber==check2.cNumber&&check1.cNumber==check3.cNumber&&check1.cNumber==check4.cNumber)//@@@@-
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check3.cNumber&&check1.cNumber==check5.cNumber)//@@@-@
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check4.cNumber&&check1.cNumber==check5.cNumber)//@@-@@
    ||(check1.cNumber==check3.cNumber&&check1.cNumber==check4.cNumber&&check1.cNumber==check5.cNumber)//@-@@@
    ||(check2.cNumber==check3.cNumber&&check2.cNumber==check4.cNumber&&check2.cNumber==check5.cNumber)//-@@@@
    ){
        console.log("Four of a Kind")
        document.getElementById("FourOfAKind").classList.add("highlight");
        multiplier=8;
    }

    //full house (three of a kind plus pair)
    else if((check1.cNumber==check2.cNumber&&check1.cNumber==check3.cNumber&&check4.cNumber==check5.cNumber&&check1.cNumber!=check4.cNumber)//@@@##
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check4.cNumber&&check3.cNumber==check5.cNumber&&check1.cNumber!=check3.cNumber)//@@#@#
    ||(check1.cNumber==check3.cNumber&&check1.cNumber==check4.cNumber&&check2.cNumber==check5.cNumber&&check1.cNumber!=check2.cNumber)//@#@@#
    ||(check2.cNumber==check3.cNumber&&check2.cNumber==check4.cNumber&&check1.cNumber==check5.cNumber&&check2.cNumber!=check1.cNumber)//#@@@#
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check5.cNumber&&check3.cNumber==check4.cNumber&&check1.cNumber!=check3.cNumber)//@@##@
    ||(check1.cNumber==check3.cNumber&&check1.cNumber==check5.cNumber&&check2.cNumber==check4.cNumber&&check1.cNumber!=check2.cNumber)//@#@#@
    ||(check2.cNumber==check3.cNumber&&check2.cNumber==check5.cNumber&&check1.cNumber==check4.cNumber&&check2.cNumber!=check1.cNumber)//#@@#@
    ||(check1.cNumber==check4.cNumber&&check1.cNumber==check5.cNumber&&check2.cNumber==check3.cNumber&&check1.cNumber!=check2.cNumber)//@##@@
    ||(check2.cNumber==check4.cNumber&&check2.cNumber==check5.cNumber&&check1.cNumber==check3.cNumber&&check2.cNumber!=check1.cNumber)//#@#@@
    ||(check3.cNumber==check4.cNumber&&check3.cNumber==check5.cNumber&&check1.cNumber==check2.cNumber&&check3.cNumber!=check1.cNumber)//##@@@
    ){
        console.log("Full House")
        document.getElementById("FullHouse").classList.add("highlight");
        multiplier=7;
    }

    //flush (all same suit)
    else if(check1.cSuit==check2.cSuit&&check1.cSuit==check3.cSuit&&check1.cSuit==check4.cSuit&&check1.cSuit==check5.cSuit){
        console.log("Flush")
        document.getElementById("Flush").classList.add("highlight");
        multiplier=5;
    }

    //straight (value down one by one, suit irrelevant)
    else if((check1.cNumber=="A"&&check2.cNumber=="K"&&check3.cNumber=="Q"&&check4.cNumber=="J"&&check5.cNumber=="10")
    ||(check1.cNumber=="K"&&check2.cNumber=="Q"&&check3.cNumber=="J"&&check4.cNumber=="10"&&check5.cNumber=="9")
    ||(check1.cNumber=="Q"&&check2.cNumber=="J"&&check3.cNumber=="10"&&check4.cNumber=="9"&&check5.cNumber=="8")
    ||(check1.cNumber=="J"&&check2.cNumber=="10"&&check3.cNumber=="9"&&check4.cNumber=="8"&&check5.cNumber=="7")
    ||(check1.cNumber=="10"&&check2.cNumber=="9"&&check3.cNumber=="8"&&check4.cNumber=="7"&&check5.cNumber=="6")
    ||(check1.cNumber=="9"&&check2.cNumber=="8"&&check3.cNumber=="7"&&check4.cNumber=="6"&&check5.cNumber=="5")
    ||(check1.cNumber=="8"&&check2.cNumber=="7"&&check3.cNumber=="6"&&check4.cNumber=="5"&&check5.cNumber=="4")
    ||(check1.cNumber=="7"&&check2.cNumber=="6"&&check3.cNumber=="5"&&check4.cNumber=="4"&&check5.cNumber=="3")
    ||(check1.cNumber=="6"&&check2.cNumber=="5"&&check3.cNumber=="4"&&check4.cNumber=="3"&&check5.cNumber=="2")
    ){
        console.log("Straight")
        document.getElementById("Straight").classList.add("highlight");
        multiplier=5;
    }

    //three of a kind
    else if((check1.cNumber==check2.cNumber&&check1.cNumber==check3.cNumber)//@@@--
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check4.cNumber)//@@-@-
    ||(check1.cNumber==check3.cNumber&&check1.cNumber==check4.cNumber)//@-@@-
    ||(check2.cNumber==check3.cNumber&&check2.cNumber==check4.cNumber)//-@@@-
    ||(check1.cNumber==check2.cNumber&&check1.cNumber==check5.cNumber)//@@--@
    ||(check1.cNumber==check3.cNumber&&check1.cNumber==check5.cNumber)//@-@-@
    ||(check2.cNumber==check3.cNumber&&check2.cNumber==check5.cNumber)//-@@-@
    ||(check1.cNumber==check4.cNumber&&check1.cNumber==check5.cNumber)//@--@@
    ||(check2.cNumber==check4.cNumber&&check2.cNumber==check5.cNumber)//-@-@@
    ||(check3.cNumber==check4.cNumber&&check3.cNumber==check5.cNumber)//--@@@
    ){
        console.log("Three of a Kind")
        document.getElementById("ThreeOfAKind").classList.add("highlight");
        multiplier=3;
    }

    //two pair
    else if((check1.cNumber==check2.cNumber&&check3.cNumber==check4.cNumber)//@@##-
    ||(check1.cNumber==check2.cNumber&&check3.cNumber==check5.cNumber)//@@#-#
    ||(check1.cNumber==check2.cNumber&&check4.cNumber==check5.cNumber)//@@-##
    ||(check1.cNumber==check3.cNumber&&check4.cNumber==check5.cNumber)//@-@##
    ||(check2.cNumber==check3.cNumber&&check4.cNumber==check5.cNumber)//-@@##
    ||(check1.cNumber==check3.cNumber&&check2.cNumber==check4.cNumber)//@#@#-
    ||(check1.cNumber==check3.cNumber&&check2.cNumber==check5.cNumber)//@#@-#
    ||(check1.cNumber==check4.cNumber&&check2.cNumber==check5.cNumber)//@#-@#
    ||(check1.cNumber==check4.cNumber&&check3.cNumber==check5.cNumber)//@-#@#
    ||(check2.cNumber==check4.cNumber&&check3.cNumber==check5.cNumber)//-@#@#
    ||(check1.cNumber==check4.cNumber&&check2.cNumber==check3.cNumber)//@##@-
    ||(check1.cNumber==check5.cNumber&&check2.cNumber==check3.cNumber)//@##-@
    ||(check1.cNumber==check5.cNumber&&check2.cNumber==check4.cNumber)//@#-#@
    ||(check1.cNumber==check5.cNumber&&check3.cNumber==check4.cNumber)//@-##@
    ||(check2.cNumber==check5.cNumber&&check3.cNumber==check4.cNumber)//-@##@
    ){
        console.log("Two Pair")
        document.getElementById("TwoPair").classList.add("highlight");
        multiplier=2;
    }


    //pair (value, not suit)
    else if((check1.cNumber==check2.cNumber)//@@---
    ||(check1.cNumber==check3.cNumber)//@-@--
    ||(check1.cNumber==check4.cNumber)//@--@-
    ||(check1.cNumber==check5.cNumber)//@---@
    ||(check2.cNumber==check3.cNumber)//-@@--
    ||(check2.cNumber==check4.cNumber)//-@-@-
    ||(check2.cNumber==check5.cNumber)//-@--@
    ||(check3.cNumber==check4.cNumber)//--@@-
    ||(check3.cNumber==check5.cNumber)//--@-@
    ||(check4.cNumber==check5.cNumber)//---@@
    ){
        console.log("Pair")
        document.getElementById("Pair").classList.add("highlight");
        multiplier=1;
    }

}

function removal(){
    document.getElementById("RoyalFlush").classList.remove("highlight");
    document.getElementById("FourOfAKind").classList.remove("highlight");
    document.getElementById("FullHouse").classList.remove("highlight");
    document.getElementById("Flush").classList.remove("highlight");
    document.getElementById("Straight").classList.remove("highlight");
    document.getElementById("ThreeOfAKind").classList.remove("highlight");
    document.getElementById("TwoPair").classList.remove("highlight");
    document.getElementById("Pair").classList.remove("highlight");
}

function debugging(){
    //royal flush (AKQJ10 straight flush)
    /*
    mycard1=cards[0]
    document.getElementById("back1").src = cardpics[0].src;1;
    mycard2=cards[12];
    document.getElementById("back2").src = cardpics[12].src;1;
    mycard3=cards[11];
    document.getElementById("back3").src = cardpics[11].src;1;
    mycard4=cards[10];
    document.getElementById("back4").src = cardpics[10].src;1;
    mycard5=cards[9];
    document.getElementById("back5").src = cardpics[9].src;1;
    */

    //four of a kind
    /*
    mycard1=cards[1]
    document.getElementById("back1").src = cardpics[1].src;1;
    mycard2=cards[14];
    document.getElementById("back2").src = cardpics[14].src;1;
    mycard3=cards[27];
    document.getElementById("back3").src = cardpics[27].src;1;
    mycard4=cards[40];
    document.getElementById("back4").src = cardpics[40].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */

    //full house (three of a kind plus pair)
    /*
    mycard1=cards[1]
    document.getElementById("back1").src = cardpics[1].src;1;
    mycard2=cards[14];
    document.getElementById("back2").src = cardpics[14].src;1;
    mycard3=cards[29];
    document.getElementById("back3").src = cardpics[29].src;1;
    mycard4=cards[40];
    document.getElementById("back4").src = cardpics[40].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */
    
    //flush (all same suit)
    /*
    mycard1=cards[0]
    document.getElementById("back1").src = cardpics[0].src;1;
    mycard2=cards[2];
    document.getElementById("back2").src = cardpics[2].src;1;
    mycard3=cards[4];
    document.getElementById("back3").src = cardpics[4].src;1;
    mycard4=cards[5];
    document.getElementById("back4").src = cardpics[5].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */

    //straight (value down one by one, suit irrelevant)
    /*
    mycard1=cards[12]
    document.getElementById("back1").src = cardpics[12].src;1;
    mycard2=cards[11];
    document.getElementById("back2").src = cardpics[11].src;1;
    mycard3=cards[10];
    document.getElementById("back3").src = cardpics[10].src;1;
    mycard4=cards[9];
    document.getElementById("back4").src = cardpics[9].src;1;
    mycard5=cards[21];
    document.getElementById("back5").src = cardpics[21].src;1;
    */

    //three of a kind
    /*
    mycard1=cards[1]
    document.getElementById("back1").src = cardpics[1].src;1;
    mycard2=cards[14];
    document.getElementById("back2").src = cardpics[14].src;1;
    mycard3=cards[23];
    document.getElementById("back3").src = cardpics[23].src;1;
    mycard4=cards[40];
    document.getElementById("back4").src = cardpics[40].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */

    //two pair
    /*
    mycard1=cards[1]
    document.getElementById("back1").src = cardpics[1].src;1;
    mycard2=cards[14];
    document.getElementById("back2").src = cardpics[14].src;1;
    mycard3=cards[29];
    document.getElementById("back3").src = cardpics[29].src;1;
    mycard4=cards[5];
    document.getElementById("back4").src = cardpics[5].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */

    //pair (value, not suit)
    /*
    mycard1=cards[1]
    document.getElementById("back1").src = cardpics[1].src;1;
    mycard2=cards[2];
    document.getElementById("back2").src = cardpics[2].src;1;
    mycard3=cards[29];
    document.getElementById("back3").src = cardpics[29].src;1;
    mycard4=cards[5];
    document.getElementById("back4").src = cardpics[5].src;1;
    mycard5=cards[3];
    document.getElementById("back5").src = cardpics[3].src;1;
    */
}



