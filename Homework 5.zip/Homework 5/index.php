<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    
<?php
    include "includes/data.php";
    include "includes/functions.php";

    $pageTitle="Book Catalog";
?>

<h1><?php echo $pageTitle; ?></h1>

<form name="sorting" method="post">
    <select id="dropdown" name="dropdown" title="dropdown">
        <option value="id">Sort By...</option>
        <option value="title">Title</option>
        <option value="year">Year</option>
        <option value="publisher">Publisher</option>
    </select>
    <!--usort($catalog, sorter(dropdown.value));
        $sort=$_POST["order"]!="choose"?$_POST["order"]:"title";
    ORDER BY ".mysql_real_escape_string($sort)." ASC-->
    <input type="submit"><!-- onsumbit="includes/functions.php/usort($catalog, sorter($_POST['dropdown']))"-->
    <?php
    if(null !== "sorting"){
        usort($catalog, sorter($_POST['dropdown']));
        $container=$catalog;

        //foreach ($catalog as $key => $value) {
            //echo "\n \$catalog[$key]: " . $value["id"] . "\n";
            //echo get_item_html($value["id"], $catalog[$key]);
            /*$container[$value["id"]]=$catalog[$value["id"]];
            echo "\n \$container[$key]: " . $value["id"] . "\n";*/
        //}
    }
    ?>
</form>

<ul class=item id=container>
    <?php
    foreach ($catalog as $key => $value) {
        echo get_item_html($value["id"], $catalog[$key]);
    }
    /*for ($order=0; $order<sizeof($catalog); $order++){
        echo get_item_html($order, $catalog[$order]);
    }*/
    /*for ($id=0; $id<sizeof($container); $id++){
        echo get_item_html($id, $container[$id]);
    }*/
    ?>
</ul>
</body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--PS C:\Users\dconl\OneDrive\Documents\Adv Web Appl code\Homework 5> c:\\xampp\\php\\php.exe -S localhost:8000-->
</head>
<body>
    
</body>
</html>