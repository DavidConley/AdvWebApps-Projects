Grade calculator ReadME
By J. David Conley

To use the application, click on the "upload" button to upload a .CSV. The CSV must list the students on the y-axis, the assignments on the x-axis, and the total possible marks for each assignment on the y=1-axis. The student scores, meanwhile, should be the number of marks they received, with no denominator.

Once it is uploaded, a table and chart will be generated.

The table can be switched between fraction and percent mode using the buttons at the top.

The chart is by default on ranges of semester total scores. Using the arrow buttons, they can be switched to graphs showing each student's scores for each assignment, with a different table for each assignment. The "slide" button flips through them in sequence until it is pressed again. The "all" button shows a line graph showing each student's grade on each assignment together. It can be exited by pressing the button again, now labeled "totals."

The "save" button downloads a .png of the application's current content.