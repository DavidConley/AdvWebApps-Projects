<?php
$depts = [
 "Customer Service" => "d009",
 "Development" => "d005",
 "Finance" => "d002",
 "Human Resources" => "d003",
 "Marketing" => "d001",
 "Production" => "d004",
 "Quality Management" => "d006",
 "Research" => "d008",
 "Sales" => "d007"]; 
?>