
<?php
if(isset($_GET['id'])){
    $clickedId = $_GET['id'];
    //$clickedId=$_COOKIE['gotVal'];
    ?>
<div class="container">
    <div class="card deptCard" style="width:100%; border:blue"><h1><?php echo array_search($clickedId,$depts) ?></h1>
        <div class="card body" style="width:100%; border:blue">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Employee Number</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Hire Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //if($_REQUEST["gotVal"]){
                        //$clickedId = $_GET['gotVal'];
                        //$clickedId=$_COOKIE['gotVal'];
                        $employees=getDept($clickedId);
                        foreach($employees as $employee):
                    ?>
                    <tr>
                        <td><?php echo $employee['emp_no']; ?></td>
                        <td><?php echo $employee['first_name']; ?></td>
                        <td><?php echo $employee['last_name']; ?></td>
                        <td><?php echo $employee['gender']; ?></td>
                        <td><?php echo $employee['hire_date']; ?></td>
                    </tr>
                    <?php endforeach;} ?>
                
                </tbody>
            </table>
        </div>
    </div>
</div>